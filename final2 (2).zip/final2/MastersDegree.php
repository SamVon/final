<?php
session_start();
include_once('connect.php');
$sql = "SELECT The_Year FROM thesis ORDER BY The_ID asc";
$result = mysqli_query($conn, $sql);


// ສະເເດງຂໍ້ມູນ ປີຮຽນ

$sql = "SELECT * FROM thesis ORDER BY The_ID asc";
$result = mysqli_query($conn, $sql);


//ຄຳສັ່ງ ໂຊ່ວຂໍ້ມູນແລະ ວົນລຸບ
$query = mysqli_query($conn, "SELECT COUNT(The_ID) FROM `thesis`");
$row = mysqli_fetch_row($query);

$rows = $row[0];

$page_rows = 28;  // 1 ໜ້າ ສດ 5 record / หน้า 

$last = ceil($rows / $page_rows);

if ($last < 1) {
    $last = 1;
}

$pagenum = 1;

if (isset($_GET['pn'])) {
    $pagenum = preg_replace('#[^0-9]#', '', $_GET['pn']);
}

if ($pagenum < 1) {
    $pagenum = 1;
} else if ($pagenum > $last) {
    $pagenum = $last;
}

$limit = 'LIMIT ' . ($pagenum - 1) * $page_rows . ',' . $page_rows;
// ຄຳສັ່ງ
$nquery = mysqli_query($conn, "SELECT  distinct t.The_ID,t.The_Lnane,t.The_Ename,The_Year,d.Adv_Lname,d.Adv_Ename,m.Major_Name,f.Field_Name,s.Stu_Lname  
FROM thesis t LEFT JOIN advise a ON t.The_ID = a.The_ID 
LEFT JOIN advisor d ON a.The_ID = d.Adv_ID 
LEFT JOIN major m ON t.The_ID = m.Major_ID 
LEFT JOIN field f ON t.The_ID = f.Field_ID
LEFT JOIN author r ON t.The_ID = r.Stu_ID
LEFT JOIN student s ON t.The_ID = s.Stu_ID
LEFT JOIN degree g ON t.De_ID = g.De_ID WHERE g.De_name = 'ປະລິນຍາໂທ'; /*$limit*/");
//ຄຳສັງສາຂາ

$paginationCtrls = '';

if ($last != 1) {

    if ($pagenum > 1) {
        $previous = $pagenum - 1;
        $paginationCtrls .= '<a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $previous . '" class="btn btn-info">Previous</a> &nbsp; &nbsp; ';

        for ($i = $pagenum - 4; $i < $pagenum; $i++) {
            if ($i > 0) {
                $paginationCtrls .= '<a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $i . '" class="btn btn-primary">' . $i . '</a> &nbsp; ';
            }
        }
    }

    $paginationCtrls .= '' . $pagenum . ' &nbsp; ';

    for ($i = $pagenum + 1; $i <= $last; $i++) {
        $paginationCtrls .= '<a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $i . '" class="btn btn-primary">' . $i . '</a> &nbsp; ';
        if ($i >= $pagenum + 4) {
            break;
        }
    }

    if ($pagenum != $last) {
        $next = $pagenum + 1;
        $paginationCtrls .= ' &nbsp; &nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $next . '" class="btn btn-info">Next</a> ';
    }
}

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ປາລິນຢາໂທ</title>

    <!-- ເອີິ້ນໃຊ້່ໜ້າຝັງຊັ້ັ້ນການເຮັດວຽກສະເເດງຂໍ່ມູນ -->
    <script type="text/javascript" src="filter/selectmM.js"></script>
    <script type="text/javascript" src="filter/selectyMD.js"></script>
    <!-- ການຄິວລີຂໍ້ມູນ -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="styleme.css">


    <!-- <style>
        .grid-container {
            display: grid;
            grid-template-columns: auto auto auto auto;
            grid-gap: 3px;
            background-color: #2196F3;
            padding: 3px;
        }

        .grid-container>div {
            background-color: rgba(255, 255, 255, 0.8);
            text-align: left;
            padding: 20px 0;
            font-size: 15px;
        }

        .item1 {
            grid-column: 1 / 5;
        }

        .btn {
            margin-top: 100px;
            /* ຄວາມຫ່າງລະຫວ່າງ button*/
        }
    </style> -->

</head>

<body>
    <?php
    include 'menu.php';
    ?>



    <div class="container mt-3">

        <!-- Nav tabs -->
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link active" data-bs-toggle="tab" href="#home">ບົດແນະນຳ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#menu1">ປະເພດບົດ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#menu2">ສົກຮຽນ</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" data-bs-toggle="tab" href="#menu3">ສາຂາຮຽນ</a>
            </li>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
            <!-- Page 1 -->
            <div id="home" class="container tab-pane active"><br>
                <?php
                while ($crow = mysqli_fetch_array($nquery)) {
                ?>
                    <div class="w3-panel w3-card-4 w3-bk  w3-padding">
                        <div class="info">
                            <div class="grid-container">
                                <div class="head">
                                    <a href="">
                                        <p>ລະຫັດ:<?php echo $crow['The_ID'] ?>&nbsp;ຊື່ບົດໂຄງການສາລາວ:&nbsp;<?php echo $crow['The_Lnane'] ?>&nbsp;ຊື່ບົດໂຄງການອັງກີດ:&nbsp;<?php echo $crow['The_Ename'] ?></p>
                                    </a>
                                </div>
                                <div class="info">
                                    <p>ອາຈານທີປືກສາ:&nbsp;<?php echo $crow['Adv_Lname'] ?>
                                        ສາຂາ:&nbsp;<?php echo $crow['Major_Name'] ?>
                                        ປະເພດບົດ:&nbsp;<?php echo $crow['Field_Name'] ?>
                                        ປີສືກສາ:&nbsp;<?php echo $crow['The_Year'] ?>
                                        ລາຍຊື່ກຸ້ມນັກສືກສາ:&nbsp;<?php echo $crow['Stu_Lname'] ?></p>
                                </div>
                                <!-- <div class="item5">
                                    <button type="button" class="btn btn-primary" data-toggle="button" aria-pressed="false" autocomplete="off">
                                        ອ່ານປື້ມໂຄ້ງການ
                                    </button>
                                </div> -->
                            </div>
                        </div>
                    </div>
                <?php } ?>
            </div>




            <!-- Page 2 -->
            <div id="menu1" class="container tab-pane fade "><br>
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                    <select name="type" id="type" onchange="selectypeMD()">
                        <option value="" style="text-align: center;">ເລືອກສາຂາ</option>
                        <?php
                        $sql = "SELECT distinct * FROM field WHERE Field_Name = 'Software' OR  Field_Name = 'Network' ORDER BY Field_ID  asc";
                        $show = mysqli_query($conn, $sql);
                        while ($row = mysqli_fetch_assoc($show)) { ?>
                            <option value="<?php echo $row["Field_Name"]; ?>">
                                <?php echo $row["Field_Name"]; ?>
                            </option>
                        <?php } ?>
                    </select>
                </form>
                          
            </div>


            <!-- Page 3 -->
            <div id="menu2" class="container tab-pane fade"><br>
                <!--  ເອົາມາຈາກ Database-->
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                    <select name="YEAR" id="YEAR" onchange="selectYear()" style="width: 200px;">
                        <option value="" style="text-align: center;">ເລືອກສົກຮຽນ</option>
                        <?php foreach ($result as $row) { ?>
                            <option style="text-align: center;" value="<?php echo $row["The_Year"]; ?>">
                                <?php echo $row["The_Year"]; ?>
                            </option>
                        <?php } ?>
                    </select>
                </form>
                <!-- ສວນສະແດງຂໍ້ມຸູນ -->
                <div id="any">


                </div>
            </div>


            <!-- Page 4 -->
            <div id="menu3" class="container tab-pane fade"><br>
                <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
                    <select name="MAJOR" id="MAJOR" onchange="selectMD()">
                        <option value="" style="text-align: center;">ເລືອກສາຂາ</option>
                        <?php
                        $sql = "SELECT * FROM major WHERE Major_Name = 'Software' OR  Major_Name = 'Network' ORDER BY Major_ID  asc";
                        $show = mysqli_query($conn, $sql);
                        while ($row = mysqli_fetch_assoc($show)) { ?>
                            <option value="<?php echo $row["Major_Name"]; ?>">
                                <?php echo $row["Major_Name"]; ?>
                            </option>
                        <?php } ?>
                    </select>
                </form>
                <!-- ສວນສະແດງຂໍ້ມຸູນ -->
                <div id="anm">


                </div>
            </div>
        </div>
    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="js/all.js"></script>
    <script src="js/bootstrap.min.bundle.js"></script>
</body>

</html>