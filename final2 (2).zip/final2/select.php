<?php
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ຄົ້ນຫາ</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="styleme.css">
</head>
<body>
    <?php
     include_once('menu.php');
    ?>
    <div class="container mt-3">

<!-- Nav tabs -->
<ul class="nav nav-tabs" role="tablist">
    <li class="nav-item">
        <a class="nav-link active" data-bs-toggle="tab" href="#home">ບົດແນະນຳ</a>
    </li>
</ul>

<!-- Tab panes -->
<div class="tab-content">
    <div id="home" class="container tab-pane active"><br>
        <?php

        // ສວນກການຄົ້ນຫາແລະຮັບຄ່າ ຈາກmenu
         $search = (isset($_GET['search'])? $_GET['search'] : '');
         if($search!=''){
            //  ຖ້າຫາກກວ່າມີຂໍ້ມູນທີ search  ມັນຈະເອີ້ນຫນ້າ show ຂຶ້ນມາ
            include('show_search.php');
         } 
        ?>
           
    </div>

</div>

     <!-- Option 1: Bootstrap Bundle with Popper -->
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="js/all.js"></script>
    <script src="js/bootstrap.min.bundle.js"></script>
</body>
</html>