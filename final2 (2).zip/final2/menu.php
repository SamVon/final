<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menu</title>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="styleme.css">

    <!-- sidebar -->
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>

    <nav class="navbar navbar-expand-lg navbar-light bg-light me-auto">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <a class="navbar-brand" href="Home.php" style="color:#2E3192;width: 9rem;">CEIT</a>



        <div class="collapse navbar-collapse d-flex justify-content-end" id="navbarTogglerDemo03">
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">

            </ul><!-- ສວນປູ້ມເຊີດ-->
            <form  class="search-bar" action="select.php" method="GET">
                <input type="text" placeholder="search anything" name="search" value="">
                <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>

            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
                <div class="bb">
                    <button class="btn_n" type="submit"><a href="Bachelor's_degree.php"><i class="fas fa-book"></i>&nbsp;ບົດຈົບຊັ້ນປະລິນຍາຕີ</a></button>
                    <button class="btn_w" type="submit"><a href="MastersDegree.php"><i class="fas fa-book-bookmark"></i>&nbsp;ບົດຈົບຊັ້ນປະລີນຍາໂທ</a></button>
                    <!-- <button class="btn_t" type="submit"><a href="Techer.php"><i class="fas fa-id-card"></i>&nbsp;ອາຈານທີ່ປືກສາ</a></button> -->
                </div>
            </ul>
            <div class="profile">
                <!-- ຜູ້ໃຊ້ລະບົບ-->
                <ul class="navbar-nav justify-content-end">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-user" style="color: #2E3192;"></i>
                        </a>

                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="Regiter.php">ລົງທະບຽນ</a></li>
                            <li><a class="dropdown-item" href="login.php">ເຂົ້າໃຊ້ລະບົບ</a></li>
                            <li><a class="dropdown-item" href="#">ອອກລະບົບ</a></li>
                        </ul>
                    </li>
                </ul>
            </div>

        </div>
    </nav>
    <!-- ສິ່ນສຸດການBar -->

    

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="js/all.js"></script>
    <script src="js/bootstrap.min.bundle.js"></script>
</body>

</html>