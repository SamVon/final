<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "final";


/* connect database*/
$conn = mysqli_connect($host, $user, $password, $database);


/* check connect*/
if(!$conn) {
     die("Connection filed" . mysqli_connect_errno());
     
}
