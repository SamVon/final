<?php
session_start();
include_once('connect.php');

if (isset($_POST['btnLogin'])) {
    $txtemail = mysqli_real_escape_string($conn, $_POST['txt_email']);
    $txtpassword = mysqli_real_escape_string($conn, md5($_POST['txt_password']));

    $sql = "SELECT *FROM user WHERE User_Email='$txtemail' AND Password='$txtpassword'";
    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
        $_SESSION['txt_email'] = $txtemail;
        $_SESSION['txt_password'] = $txtpassword;
        header("location: Home.php");
    } else {
        $message = '<script> swal("ຜິດພາດ", "ບັນຊີເຂົ້າໃຊ້ ແລະ ລະຫັດຜ່ານບໍ່ຖືກຕ້ອງ!",
         "error", {button: "ຕົກລົງ"});</script>';
    }
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login </title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="style.css">
</head>

<body>
    <?= @$message ?>
    <div class="row g-0">
        <div class="col-sm-6 col-md-7">
            <div class="rightside d-flex flex-column justify-content-center align-items-center">
                <div class="p-2">
                    <h1>ຄັງຂໍ້ມູນບົດວິທະຍານິພົນ ແລະ ບົດໂຄງການຈົບຊັ້ນ</h1>
                </div>
                <div class="p-2">
                    <h3>ພາກວິຊາ ວິສະວະກຳຄອມພິວເຕີ ແລະ ເຕັກໂນໂລຊີຂໍ້ມມູນຂ່າວສານ</h3>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-5">
            <div class="leftside  d-flex justify-content-center align-items-center">
                <div class="center">
                    <h1>ເຂົ້າໃຊ້ລະບົບ</h1>
                    <form name="f1" onsubmit="return validation()" method="POST">
                        <div class="txt_field">
                            <input type="email" name="txt_email" id="txt_email" required>
                            <span></span>
                            <label for="">ອີເມວ</label>
                        </div>
                        <div class="txt_field">
                            <input type="password" name="txt_password" id="txt_password" required>
                            <span></span>
                            <label for="">ລະຫັດຜ່ານ</label>
                        </div>
                        <input type="submit" name="btnLogin" value="ເຂົ້າໃຊ້ລະບົບ"><?php ?>
                        <div class="signup_link">
                            ຕ້ອງການລົງທະບຽນເຂົ້າໃຊ້ລະບົບ? <a href="Regiter.php">ລົງທະບຽນເຂົ້າໃຊ້</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/sweetalert.min.js"></script>
</body>

</html>