function selectMD(){
    // ເອົາໄອດີມາໃຊ້ຈາກໜ້າຫຼັກ
    var x = document.getElementById("MAJOR").value;
    $.ajax({
        url:"filter/select_majorM.php",
        method:"POST",
        data:{
            id : x
        },
        success:function(data){
            $("#anm").html(data);
        }
    })
}