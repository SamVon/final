function selectBrand(){
    // ເອົາໄອດີມາໃຊ້ຈາກໜ້າຫຼັກ
    var x = document.getElementById("MAJOR").value;
    $.ajax({
        url:"filter/select_major.php",
        method:"POST",
        data:{
            id : x
        },
        success:function(data){
            $("#ans").html(data);
        }
    })
}