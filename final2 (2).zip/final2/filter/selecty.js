function selectYear(){
    // ເອົາໄອດີມາໃຊ້ຈາກໜ້າຫຼັກ
    var x = document.getElementById("YEAR").value;
    $.ajax({
        url:"filter/select_yesr.php",
        method:"POST",
        data:{
            id : x
        },
        success:function(data){
            $("#any").html(data);
        }
    })
}