<?php
session_start();
include_once('connect.php');
$query = mysqli_query($conn, "SELECT COUNT(Adv_ID) FROM `advisor`");
$row = mysqli_fetch_row($query);

$rows = $row[0];

$page_rows = 5;  //จำนวนข้อมูลที่ต้องการให้แสดงใน 1 หน้า  ตย. 5 record / หน้า 

$last = ceil($rows / $page_rows);

if ($last < 1) {
    $last = 1;
}

$pagenum = 1;

if (isset($_GET['pn'])) {
    $pagenum = preg_replace('#[^0-9]#', '', $_GET['pn']);
}

if ($pagenum < 1) {
    $pagenum = 1;
} else if ($pagenum > $last) {
    $pagenum = $last;
}

$limit = 'LIMIT ' . ($pagenum - 1) * $page_rows . ',' . $page_rows;

$nquery = mysqli_query($conn, "SELECT * from  advisor $limit");

$paginationCtrls = '';

if ($last != 1) {

    if ($pagenum > 1) {
        $previous = $pagenum - 1;
        $paginationCtrls .= '<a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $previous . '" class="btn btn-info">Previous</a> &nbsp; &nbsp; ';

        for ($i = $pagenum - 4; $i < $pagenum; $i++) {
            if ($i > 0) {
                $paginationCtrls .= '<a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $i . '" class="btn btn-primary">' . $i . '</a> &nbsp; ';
            }
        }
    }

    $paginationCtrls .= '' . $pagenum . ' &nbsp; ';

    for ($i = $pagenum + 1; $i <= $last; $i++) {
        $paginationCtrls .= '<a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $i . '" class="btn btn-primary">' . $i . '</a> &nbsp; ';
        if ($i >= $pagenum + 4) {
            break;
        }
    }

    if ($pagenum != $last) {
        $next = $pagenum + 1;
        $paginationCtrls .= ' &nbsp; &nbsp; <a href="' . $_SERVER['PHP_SELF'] . '?pn=' . $next . '" class="btn btn-info">Next</a> ';
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ອາຈານທີປືກສາ</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="stylete.css">
</head>

<body>
    <?php
    include 'menu.php';
    ?>

    <div class="container">
        <div class="row justify-content-start">

            <?php
            while ($crow = mysqli_fetch_array($nquery)) {
            ?>
                <div class="col mr-3">
                    <div class="container mt-3 ">
                        <div class="card border border-primary" style="width:300px;height:300px">
                            <!-- <img class="card-img-top" src="#" alt="Card image" style="width:100%"> --><i class="fas fa-user-circle mt-5" style='font-size:80px;color:#2691d9'></i>
                            <div class="card-body text-center">
                                <h4 class="card-title"><?php echo $crow['Adv_Lname'] ?></h4>
                                <p class="card-text"><?php echo $crow['Adv_Ename'] ?></p>
                                <!-- ປຸ່ມໂຊ່ວ -->
                                <div class="container mt-3">
                                    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#myModal<?php echo $crow['Adv_ID'] ?>">
                                        ອ່ານລາຍລະອຽດ
                                    </button>
                                </div>

                                <!-- The Modal -->
                                <div class="modal fade mt-5" id="myModal<?php echo $crow['Adv_ID'] ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">

                                            <!-- Modal Header -->
                                            <div class="modal-header">
                                                <h4 class="modal-title">ລາຍລະອຽດອາຈານທີປືກສາ</h4>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>

                                            <!-- Modal body -->
                                            <div class="modal-body">
                                                <h4 class="card-title">ຊື່ອາຈານ:&nbsp;<?php echo $crow['Adv_Lname'] ?></h4>
                                                <p class="card-text">ຊື່ອາຈານ(ພາສາອັງກິດ):&nbsp;<?php echo $crow['Adv_Ename'] ?></p>
                                                <p class="card-text">ສາຂາ:&nbsp;<?php echo $crow['Adv_Major'] ?></p>
                                                <p class="card-text">ຕຳແໜ່ງ:&nbsp;<?php echo $crow['Adv_Position'] ?></p>
                                                <p class="card-text">ຕຳແໜ່ງ:&nbsp;<?php echo $crow['Adv_Tel'] ?></p>
                                                <p class="card-text">Email:&nbsp;<?php echo $crow['Adv_Email'] ?></p>
                                            </div>

                                            <!-- Modal footer -->
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-danger" data-bs-dismiss="modal">ປິດ</button>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <!-- ທ້າຍ -->
                            </div>
                        </div>
                    </div>
                    <!-- ສວນກາດອາຈານ-->
            </div>
            <?php } ?>
        </div>
        <?php mysqli_close($conn); ?>
        <!-- ເລືອກໜ້າ -->
        <div id="pagination_controls"><?php echo $paginationCtrls; ?></div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
    <script src="js/all.js"></script>
    <script src="js/bootstrap.min.bundle.js"></script>
</body>

</html>