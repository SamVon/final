<?php
session_start();
include_once('connect.php');
if (isset($_POST['submit'])) {
    $name = $_POST['Username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $sql = "INSERT INTO user (Username,User_Email,User_Pass)
     VALUES ('$name','$email','$password')";
    if (mysqli_query($conn, $sql)) {
        $message = '<script> swal("ຍິນຕ້ອນຮັບ", "ສາມາດລ໋ອກອິນໄດ້!",
         {button: "ຕົກລົງ"});</script>';
    } else {
        echo "Error: " . $sql . ":-" . mysqli_error($conn);
    }
    mysqli_close($conn);
}


?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <title>Register</title>

    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="Styleegg.css">

</head>

<body>
    <?= @$message ?>
    <div class="row g-1">
        <div class="col-sm-6 col-md-5">
            <div class="rightside d-flex flex-column justify-content-center align-items-center">
                <div class="center">
                    <h1>ລົງທະບຽນເຂົ້າໃຊ້ລະບົບ</h1>
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                        <div class="txt_field">
                            <input type="text" id="Username" name="Username" required>
                            <span></span>
                            <label for="">ຊື່ ແລະ ນາມສະກຸູນ</label>
                        </div>
                        <div class="txt">
                            <i class="fa-regular fa-address-card"></i><label for="">ຕຳແໜ່ງ</label>
                        </div>
                        <!-- ສວນເຊັກບ໋ອກ-->
                        <div class="txt_box">
                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="Techer" name="checkbox" value="Techer">
                                <label class="form-check-label" for="exampleCheck1">ອາຈານ</label>
                            </div>

                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="Student" name="checkbox" value="Student">
                                <label class="form-check-label" for="exampleCheck1">ນັກສືກສາ</label>
                            </div>

                            <div class="mb-3 form-check">
                                <input type="checkbox" class="form-check-input" id="Other" name="checkbox" value="Other">
                                <label class="form-check-label" for="exampleCheck1">ອື່ນຯ</label>
                            </div>


                        </div>

                        <div class="txt_field">
                            <input type="email" id="Email" name="email" value="" required>
                            <span></span>
                            <label for="">ອີເມວ</label>
                        </div>
                        <div class="txt_field">
                            <input type="password" id="password" name="password" required>
                            <span></span>
                            <label for="">ລະຫັດຜ່ານ</label>
                        </div>
                        <div class="txt_field">
                            <input type="password" id="con_password " name="con_password" required>
                            <span></span>
                            <label for="">ຢືນຢັນລະຫັດຜ່ານ</label>
                        </div>
                        <input type="submit" name="submit" value="ລົງທະບຽນເຂົ້າໃຊ້"></input>
                        <div class="signup_link">
                            ຕ້ອງການເຂົ້າໃຊ້ລະບົບ? <a href="login.php">ເຂົ້າໃຊ້ລະບົບ</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>



        <div class="col-sm-6 col-md-7">
            <div class="leftside  d-flex flex-column justify-content-center align-items-center">
                <div class="p-2">
                    <h1>ຄັງຂໍ້ມູນບົດວິທະຍານິພົນ ແລະ ບົດໂຄງການຈົບຊັ້ນ</h1>
                </div>
                <div class="p-2">
                    <h3>ພາກວິຊາ ວິສະວະກຳຄອມພິວເຕີ ແລະ ເຕັກໂນໂລຊີຂໍ້ມມູນຂ່າວສານ</h3>
                </div>
            </div>
        </div>
    </div>
    <script src="js/sweetalert.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
</body>

</html>