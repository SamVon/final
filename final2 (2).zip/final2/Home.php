<?php
include_once('connect.php');

?>




<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
  <link rel="stylesheet" href="css/all.min.css"> <!-- awesome icon-->
  <title>Home</title>
  <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
  <link rel="stylesheet" href="fontawesome/css/all.min.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="styleHome.css">

</head>

<body>
  <nav class="navbar">
    <div class="container-fluid">
      <CEIT class="navbar-brand" href="#">CEIT</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#collapsibleNavbar">
          <span class="navbar-toggler-icon"></span>
        </button>
        </a>
    </div>
    </div>

  </nav>
  <!-- ສວນໂຕພາສາ-->
  <div class="row g-1 d-flex flex-column justify-content-center align-items-center">
    <div class="col-sm-6 col-md-7">
      <div class="rightside d-flex flex-column justify-content-center align-items-center">
        <div class="p-2">
          <h1>ຄັງຂໍ້ມູນບົດວິທະຍານິພົນ ແລະ ບົດໂຄງການຈົບຊັ້ນ</h1>
        </div>
        <div class="p-2">
          <h3>ພາກວິຊາ ວິສະວະກຳຄອມພິວເຕີ ແລະ ເຕັກໂນໂລຊີຂໍ້ມມູນຂ່າວສານ</h3>
        </div>
      </div>
    </div>
    <!-- ສວນຄົ້ນຫາ-->
    <div class="col-sm-6 col-md-7">
      <div class="rightside d-flex flex-column justify-content-center align-items-center">
        <form action="select.php" class="search-bar" method="GET">
          <input type="text"  placeholder="search anything" name="search"  value="">
          <button type="submit" class="btn btn-primary"><i class="fa-solid fa-magnifying-glass"></i><a href="select.php"></a></button>
        </form>
      </div>
    </div>

    <div class="col-sm-6 col-md-7">
      <div class="btn d-flex flex column justify-content-center align-items-center">
        <div class="bb">
          <button class="btn_n" type="submit"><a href="Bachelor's_degree.php"><i class="fas fa-book"></i>&nbsp;ບົດຈົບຊັ້ນປະລິນຍາຕີ</a></button>
          <button class="btn_w" type="submit"><a href="MastersDegree.php"><i class="fas fa-book-bookmark"></i>&nbsp;ບົດຈົບຊັນປະລີນຍາໂທ</a></button>
          <!-- <button class="btn_t" type="submit"><a href="Techer.php"><i class="fas fa-id-card"></i>&nbsp;ອາຈານທີປືກສາ</a></button> -->
        </div>

      </div>
    </div>





    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="js/all.js"></script>
    <script src="js/bootstrap.min.bundle.js"></script>
</body>

</html>